#!/usr/bin/env python
# -*- coding: utf-8 -*-


class ValidationError(Exception):
    pass